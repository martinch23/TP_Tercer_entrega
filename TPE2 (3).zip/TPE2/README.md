Integrantes:- Salvador, Guido Gabriel. email: guidsalv@gmail.com 
            - Christensen, Martín. email: martin.christensen93@gmail.com

Temática: Página para ver series

Descripción: Realizaremos una página para ver series, que ofrece diversos generos y tipos de series.



DIAGRAMA ENTIDAD RELACION:
![image](https://github.com/martinch23/TpWeb2/assets/106201096/88e120e1-0da6-4b63-9ce3-a336c1914ae6)


